import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.util.Random;

public class Game {

  /* for now the game is hardocded for three players but can be changed to take user input for more/less players. An array of counters could be made, or a method to randomly generate one, and each be assigned to an element of the player array.
  */

  Player[] players = new Player[3];

  /* Here we can assign the players from the array just created to a counter and choose which player we want to be human (true) and which is to be computer (false).
  */ 
  Game() {
    players[0] = new Player('a', true);
    players[1] = new Player('b', false);
    players[2] = new Player('c', false);
  }
// Set the turn from zero, initialises the board, create the random number for the computer to use and create the scanner for the programme to take user input.
  private int currentTurn = 0;
  Board board;
  Random random = new Random();
  private Scanner input = new Scanner(System.in);
  
  // Generate random integers in range 0 to 7 for computer input
  private int getCompInput(){
    int compInput = random.nextInt((board.numColumns - 1) + 1) + 1;
    return compInput;
  }

// Main method of programme. Takes information from the Board class if the place chosen by either computer or user is a winning move and prints the baord with the new positions
  public void playGame() {

    System.out.println(
        "\nWelcome to ConnectN!\n\nThere are 3 players 'a', 'b' and 'c'.\n\nTo play the game, type in the number of the column you want to drop your counter in.\n\nThe player wins by connecting the number of counters specified  in a row - vertically, horizontally or diagonally.\n\n");
    
    // Ask what the winning condition is then creates a board from it
    Integer winConditionInt = getUserInputWinCondition();
    board = new Board(winConditionInt);
    System.out.println();
    boolean win = false;
    while (!win) {
      // initially we want to print a blank board for the player(s) to read.
      board.printBoard();
      // by modularising the currentTurn by the total amount of players we can ascertain the current player so the compiler knows which counter to place.      
      int currentPlayerNum = (currentTurn % players.length);
      Player currentPlayer = players[currentPlayerNum];
      Integer position;
      // checks the player is human or computer
      if (currentPlayer.getIsHuman()) {
        position = getUserInputPosition();
      } else {
        position = getCompInput();
      }
      // places new counter on the board
      placeCounter(position, currentPlayer);
      boolean hasWon = board.checkForWin(currentPlayer);
      if (hasWon) {
        win = true;
      }
      // check to see if the board is full and neither players can win
      if (currentTurn == board.turnsTotal){
        System.out.println("We have a tie!!!");
        return;
      } else { currentTurn++;
      }
    }
    // winning message produced for current player if winning criteria is met
    board.printBoard();
    System.out.println("Winner!!!");
  }

  // Setting the userInput to null and forcing them to provide an integer within the games parameters.
  public Integer getUserInputPosition() {
    String userInput = null;
    Integer userInputInt = null;
    while (userInputInt == null) {
      System.out.print("Choose a column to place your counter: ");
      try {
        userInput = input.nextLine();
        System.out.println();
        userInputInt = Integer.parseInt(userInput);
        if (userInputInt < 1 || userInputInt > board.numColumns) {
          throw new IllegalArgumentException();
        }
      } catch (NumberFormatException e) {
        System.out.print("Please enter a valid number: ");
        userInputInt = null;
      } catch (IllegalArgumentException e) {
        System.out.print("Please enter a number between 1 and " + board.numColumns + ": ");
        userInputInt = null;
      }
    }
    return userInputInt;
  }

  /* Here is a method asking the user for the winning condition (how many counters, 'N', in a row) which must be between 2 < N < 7. To be clear this does not include 2 and 7.
  */

  public Integer getUserInputWinCondition() {
    String userInput = null;
    Integer userInputInt = null;
    while (userInputInt == null) {
      System.out.print("Choose the number of counters (between 2 and 7) in a row needed to win: ");
      try {
        userInput = input.nextLine();
        userInputInt = Integer.parseInt(userInput);
        if (userInputInt < 3 || userInputInt > 6) {
          throw new IllegalArgumentException();
        }
      } catch (NumberFormatException e) {
        System.out.print("Please enter a valid integer: ");
        userInputInt = null;
      } catch (IllegalArgumentException e) {
        System.out.print("Please enter an integer within range specified: ");
        userInputInt = null;
      }
    }
    return userInputInt;
  }

// Method for placing the counter at the positiopn provided byt the user or computer.
  public void placeCounter(Integer position, Player currentPlayer) {
    boolean placed = false;
    for (int i = 0; i < board.numRows; i++) {
      if (!placed) {
        if (board.board[i][position - 1] == ' ') {
          board.board[i][position - 1] = currentPlayer.getCounter();
          placed = true;
        }
      }
    }
  }

}