import java.util.*;

public class Player {
  
  private char counter;
  private boolean isHuman;

//  Check if the player is human or computer with constructors to use values in the Game class.
  public Player(char counter, boolean isHuman){
    this.counter = counter;
    this.isHuman = isHuman;
  }

  public char getCounter(){
    return counter;
  }

  public boolean getIsHuman(){
    return isHuman;
  }
} 
